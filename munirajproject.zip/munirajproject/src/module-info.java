/**
 * 
 */
/**
 * @author haigu
 *
 */
module munirajproject {
	requires java.sql;
}